from collections import Counter
import re
from datetime import datetime as dt
from operator import itemgetter

def openLogFile(path):
    with open(path) as log_file:
        for log_entry in log_file:
            yield log_entry


def parseZeekConn(log_entry):
    log_data = re.split("\t", log_entry.rstrip())
    r = {}
    r["ts"] = dt.fromtimestamp(float(log_data[0]))
    r["uid"] = log_data[1]
    r["src_ip"] = log_data[2]
    r["src_port"] = log_data[3]
    r["dst_ip"] = log_data[4]
    r["dst_port"] = log_data[5]
    r["proto"] = log_data[6]
    r["service"] = log_data[7]
    r["duration"] = log_data[8]
    r["src_bytes"] = log_data[9]
    r["dst_bytes"] = log_data[10]
    r["conn_state"] = log_data[11]
    r["local_src"] = log_data[12]
    r["local_rsp"] = log_data[13]
    r["missed_bytes"] = log_data[14]
    r["history"] = log_data[15]
    r["srk_pkts"] = log_data[16]
    r["src_ip_bytes"] = log_data[17]
    r["dst_pkts"] = log_data[18]
    r["dst_ip_bytes"] = log_data[19]
    r["tunnel_parents"] = log_data[20]
    return r

    
    

def getHTTPByUID(path):
    counter = Counter()
    file = openLogFile(path)
    for log_entry in file:
        try:
            data = parseZeekConn(log_entry)
            counter.update([data["uid"]])
        except:
            pass
    return counter



def detectBeacons(conn_path, http_path):
    req = getHTTPByUID(http_path)
    conn_file = openLogFile(conn_path)
    possible_beacons=[]
    for log_entry in conn_file:
        try:
            parsed_data = parseZeekConn(log_entry)
            if parsed_data["service"] == "http" and parsed_data["uid"] in req:
                parsed_data["requests"] = req[parsed_data["uid"]]
                possible_beacons.append(parsed_data)
        except:
            pass

    possible_beacons.sort(key=itemgetter("requests"), reverse=True)

    header=("{:20}\t{:20}\t{:20}\t{:20}".format("dst_ip","src_IP","Requests","Service"))
    print(header)
    print("-"*(len(header)+10))    
    for entry in possible_beacons[:8]:
        print("{:20}\t{:20}\t{:20}\t{:20}".format(entry["dst_ip"],entry["src_ip"],entry["requests"],entry["service"]))

