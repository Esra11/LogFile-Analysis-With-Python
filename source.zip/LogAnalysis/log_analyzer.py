import re
from datetime import datetime as dt
import Evtx.Evtx as evtx
from collections import Counter
from operator import itemgetter
from difflib import SequenceMatcher
import matplotlib.pyplot as plt
from pymongo import MongoClient
from geoip import geolite2
from elasticsearch import Elasticsearch

def openEvtxFile(path):
    with evtx.Evtx(path) as log_file:
        for log_entry in log_file.records():
            yield log_entry.lxml()


def parseEvtx(event):
    sys_tag = event.find("System", event.nsmap)
    event_id = sys_tag.find("EventID", event.nsmap)
    event_ts = sys_tag.find("TimeCreated", event.nsmap)
    event_data = event.find("EventData", event.nsmap)
    r={}
    r["ts"] = event_ts.values()[0]
    r["eid"] = event_id.text
    for data in event_data.getchildren():
        r[data.attrib["Name"]] = data.text
    return r


def detectRundll32(path):
    file = openEvtxFile(path)
    for log_entry in file:
        try:
            parsedEvent = parseEvtx(log_entry)
            if parsedEvent["eid"] == '4688' and parsedEvent["CommandLine"]:
                if "rundll32" in parsedEvent["NewProcessName"].lower() and re.search("powershell|cmd",parsedEvent["ParentProcessName"].lower()):
                    print(parsedEvent["CommandLine"])
        except:
            pass 




def openLogFile(path):
    with open(path) as log_file:
        for log_entry in log_file:
            yield log_entry





# def openLogFile(path):
#     x=[]
#     with open(path) as log_file:
#         for log_entry in log_file:
#             x.append(log_entry)
#     return x

def parseZeekConn(log_entry):
    log_data = re.split("\t", log_entry.rstrip())
    r = {}
    r["ts"] = dt.fromtimestamp(float(log_data[0]))
    r["uid"] = log_data[1]
    r["src_ip"] = log_data[2]
    r["src_port"] = log_data[3]
    r["dst_ip"] = log_data[4]
    r["dst_port"] = log_data[5]
    r["proto"] = log_data[6]
    r["service"] = log_data[7]
    r["duration"] = log_data[8]
    r["src_bytes"] = log_data[9]
    r["dst_bytes"] = log_data[10]
    r["conn_state"] = log_data[11]
    r["local_src"] = log_data[12]
    r["local_rsp"] = log_data[13]
    r["missed_bytes"] = log_data[14]
    r["history"] = log_data[15]
    r["srk_pkts"] = log_data[16]
    r["src_ip_bytes"] = log_data[17]
    r["dst_pkts"] = log_data[18]
    r["dst_ip_bytes"] = log_data[19]
    r["tunnel_parents"] = log_data[20]
    return r

def parseZeekDns(log_entry):
    log_data = re.split("\t", log_entry.rstrip())
    r = {}
    r["ts"] = dt.fromtimestamp(float(log_data[0]))
    r["uid"] = log_data[1]
    r["src_ip"] = log_data[2]
    r["src_port"] = log_data[3]
    r["dst_ip"] = log_data[4]
    r["dst_port"] = log_data[5]
    r["proto"] = log_data[6]
    r["trans_id"] = log_data[7]
    r["rtt"] = log_data[8]
    r["query"] = log_data[9]
    r["qclass"] = log_data[10]
    r["qclass_name"] = log_data[11]
    r["qtype"] = log_data[12]
    r["qtype_name"] = log_data[13]
    r["rcode"] = log_data[14]
    r["rcode_name"] = log_data[15]
    r["AA"] = log_data[16]
    r["TC"] = log_data[17]
    r["RD"] = log_data[18]
    r["RA"] = log_data[19]
    r["Z"] = log_data[20]
    r["answers"] = log_data[21]
    r["TTLs"] = log_data[22]
    r["rejected"] = log_data[23]
    return r

def parse_smb(log_entry):
    pattern = r"^(?P<ts>[0-9]{2}:[0-9]{2}:[0-9]{2})\s:\s(?P<client_hostname>[a-zA-Z0-9\-]+)\|(?P<client_IP>[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3})\|(?P<share>[a-zA-Z0-9\-]+)\|(?P<operation>[a-zA-Z]+)\|ok\|(?P<path>.*)$"
    log_data = re.search(pattern, log_entry)
    result = log_data.groupdict()
    result['ts'] = dt.strptime(result['ts'], "%H:%M:%S") # because some other functions need to call datetime functions on this field 
    return result

def getHTTPByUID(path):
    counter = Counter()
    file = openLogFile(path)
    for log_data in file:
        try:
            parsed_data = parseZeekConn(log_data)
            counter.update([parsed_data["uid"]]) # if I miss [] around [parsed_data["uid"]] will get false result!!
        except:
            pass
    return counter

def detectBeacons(conn_path, http_path):
    req = getHTTPByUID(http_path)
    conn_log = openLogFile(conn_path)
    beacons=[]
    for log_entry in conn_log:
        try:
            parsed_data = parseZeekConn(log_entry)
            if parsed_data["service"] == "http" and parsed_data["uid"] in req:
                parsed_data["requests"] = req[parsed_data["uid"]]
                beacons.append(parsed_data)
        except:
            pass
    
    beacons.sort(key=itemgetter("requests"),reverse=True) #from operator import itemgetter

    header=("{:20}\t{:20}\t{:20}\t{:20}".format("dst_ip","src_IP","Requests","Service"))
    print(header)
    print("-"*(len(header)+10))
    for entry in beacons[:8]:
        print("{:20}\t{:20}\t{:20}\t{:20}".format(entry['dst_ip'],entry['src_ip'],entry['requests'],entry['service']))


def getDnsAnomalies(path, similar_domain='globomantics.com'):
    log_file = openLogFile(path)
    domains = Counter()
    for log_entry in log_file:
        try:
            log_data = parseZeekDns(log_entry)
            dns_query = ".".join(log_data["query"].split(".")[-2:])
            domains.update([dns_query])
        except:
            pass
    least_common = domains.most_common()[-10:]
    domain_anomalies=[]
    for domain in least_common:
        anomaly={
            "domain":domain[0],
            "occurence":domain[1],
            "similarity": round(SequenceMatcher(None,domain[0],similar_domain).ratio()*100)
        }
        domain_anomalies.append(anomaly)
    domain_anomalies.sort(key=itemgetter("similarity"),reverse=True)
    return domain_anomalies

def printDnsAnomalies(path):
    domains = getDnsAnomalies(path)
    header =("{:20}\t{:20}\t{:20}".format("Domain","Occurence","Similarity"))
    print(header)
    print("-"*len(header))
    for domain in domains:
        print("{:20}\t{:20}\t{:20}".format(domain["domain"],domain["occurence"],domain["similarity"]))


def printDnsQueries(path, domain):
    log_file = openLogFile(path)
    for log_entry in log_file:
        try:
            log_data = parseZeekDns(log_entry)
            if domain in log_data['query']:
                print("{}\t{}".format(log_data["query"], log_data["answers"]))
        except:
            pass

def plotEvents(events, users): #events is a dictionary
    plt.subplot(211)
    plt.bar(range(len(events)), list(events.values()), align="center")
    plt.xticks(range(len(events)), list(events.keys()))
    plt.subplot(212)
    plt.bar(range(len(users)), list(users.values()), align="center")
    plt.xticks(range(len(users)), list(users.keys()))
    plt.show()


def plotSMBActivity(path):
    log_file=openLogFile(path)
    users = Counter()
    events = Counter()
    for log_entry in log_file:
        try:
            log_data = parse_smb(log_entry)
            users.update([log_data["client_hostname"]])
            #ts = log_data["ts"].strftime("%H:%M")
            ts = getBaseTs(log_data["ts"],4)
            events.update([ts])
        except:
            pass
    plotEvents(events)

def getBaseTs(ts, interval):
    # divide an hour into the interval number of sections
    interval = int(60 / interval)

    hours = ts.time().hour
    minutes = ts.time().minute

    base_minutes = int(minutes / interval) * interval
    return "{}:{}".format(hours,base_minutes)


def ransomwareAlert(path="../logs/smb.log"):
    pattern = r"\.locked|\.encrypted|\.wncry"
    client = MongoClient("mongodb://localhost")
    db = client["alerts"]
    collection = db["smb"]
    log_file = openLogFile(path)
    for log_record in log_file:
        try:
            log_data = parse_smb(log_record)
            if re.search(pattern,log_data["path"]):
                log_data["ts_added"] = dt.utcnow()
                collection.insert_one(log_data)
            
        except:
            pass 


def parseAuth(log_entry):
    log_data = re.search(
        # Jul 28 18:02:26
        r"^(?P<ts>\w{3}\s\d{1,2}\s\d{1,2}:\d{1,2}:\d{1,2})" + 
        # hostname-01
        r"\s(?P<host>[\w\-]+)" +
        # sshd[5577]:
        r"\s(sshd\[\d{1,6}\]):" +
        # Failed password for[ invalid user]
        r"\s(?P<action>Failed|Accepted) password for(\s(?P<invalid>invalid user))?" +
        # root
        r"\s(?P<user>[^\s]+)" +
        r"\s(from)" +
        # 127.0.0.1
        r"\s(?P<ip>\d{1,3}.\d{1,3}.\d{1,3}.\d{1,3})" +
        # port 51106 ssh2
        r".*$", log_entry)

    r = log_data.groupdict()
    r['ts'] = dt.strptime(r['ts'], r"%b %d %H:%M:%S")
    r['ts'] = r['ts'].replace(year=dt.utcnow().year)
    r['country'] = geolite2.lookup(r['ip']).country
    return r

def exportSSHActivity(path="../logs/auth.log"):
    es = Elasticsearch("http://localhost:9200")
    log_file = openLogFile(path)
    for log_entry in log_file:
        try:
            log_data = parseAuth(log_entry)
            es.index(index="auth", document=log_data)
        except:
            pass